# Germana Capital V81 Concept Claim Substantiation

Last updated: 2026-04-28

This file supports the marketing and compliance review of the v80 concept website. It is not a legal opinion and should be reviewed by the firm's compliance consultant or counsel before publication.

## Review Principles

The website copy was written to be fair, balanced, supportable, and free of performance promises, testimonials, rankings, or unsupported superlatives. The copy avoids guarantees, "conflict-free" language, and claims that a visitor will receive individualized investment, tax, or legal advice from the website.

Primary public sources to keep in the compliance archive:

- SEC Investment Adviser Marketing compliance guide: https://www.sec.gov/resources-small-businesses/small-business-compliance-guides/investment-adviser-marketing
- SEC 2024 Risk Alert on Investment Adviser Marketing Rule compliance: https://www.sec.gov/compliance/risk-alerts/risk-alert-041724
- Texas registered investment adviser registration overview: https://www.ssb.texas.gov/securities-professionals/dealer-adviser-registration/getting-started-registered-investment-adviser
- IAPD firm profile for Germana Capital LLC, CRD 321214: https://adviserinfo.sec.gov/firm/summary/321214
- IRS estate tax guidance for nonresidents who are not U.S. citizens: https://www.irs.gov/businesses/small-businesses-self-employed/estate-tax-for-nonresidents-not-citizens-of-the-united-states
- IRS taxation of nonresident aliens: https://www.irs.gov/individuals/international-taxpayers/taxation-of-nonresident-aliens
- IRS self-employed individuals tax center: https://www.irs.gov/businesses/small-businesses-self-employed/self-employed-individuals-tax-center
- IRS gambling winnings overview: https://www.irs.gov/taxtopics/tc419
- IRS gifts and inheritances FAQ: https://www.irs.gov/faqs/interest-dividends-other-types-of-income/gifts-inheritances/gifts-inheritances
- IRS Publication 4345 on settlements and judgments: https://www.irs.gov/pub/irs-pdf/p4345.pdf
- Investor.gov private equity overview: https://www.investor.gov/introduction-investing/investing-basics/investment-products/private-investment-funds/private-equity

## Claim Matrix

| Website wording | Support needed before launch | Compliance note |
|---|---|---|
| State-registered investment adviser registered in Florida and Texas | Current IAPD profile and state registration records | Recheck before launch and at least quarterly. |
| Fee-only advisory model / no product commissions | Current Form ADV Part 2A, advisory agreement, fee schedule, accounting records | Avoid "conflict-free"; use "designed to reduce product-compensation conflicts." |
| Fiduciary advisory relationship | Form ADV, advisory agreement, regulatory framework | Do not imply a guaranteed outcome. |
| Client assets generally held at independent third-party custodians | Form ADV custody disclosures and custodian platform records | Avoid absolute custody claims if exceptions exist. |
| South Florida property and U.S.-situated assets may create U.S. estate tax exposure for nonresident noncitizens | IRS nonresident estate tax guidance and tax counsel review | Keep as general educational information, not tax advice. |
| 1099, endorsement, NIL, or platform income can create tax and cash-flow planning complexity | IRS self-employed tax center and tax professional review | Use "can" or "may" because facts vary. |
| Sudden wealth examples including inheritance, legal settlement, lottery or prize winnings, insurance proceeds, business sale, bonus, or other one-time money events can create tax, legal, liquidity, family, and investment planning questions | IRS gambling winnings guidance, IRS inheritance FAQ, IRS Publication 4345, professional tax/legal review, and intake records | Use "can" and "may"; avoid implying uniform tax treatment or individualized advice. Encourage coordination with qualified tax and legal professionals. |
| Private-market opportunities may be evaluated for eligible clients | Offering documents, due diligence records, eligibility process | Risk language must appear near private-market discussion. |
| Private investments can involve illiquidity, valuation uncertainty, limited transparency, higher fees, and possible loss of principal | Investor.gov and offering documents | Do not imply enhanced return or special access. |
| Miami / Brickell office address | Lease, Form ADV, Google Business Profile, business records | Keep address consistent across schema, footer, contact page, and Form ADV. |
| "You do not need to speak finance" / plain-English education | Internal marketing positioning and page copy archive | Framed as communication style, not expertise superiority or a promise of outcome. |
| Interactive quiz/path-finder results | Archive of quiz logic in `assets/site.js` and copy review | Results are educational routing suggestions only. They must not be treated as individualized advice or recommendations. |
| Creator, athlete, business owner, professional, and international pain-point examples | IRS, IAPD, Form ADV, professional experience, and client-service scope review | Framed as common situations and planning questions, not client testimonials or guaranteed problems. |
| Ask an Advisor video topic form | Website archive and form copy | Form is for educational topic suggestions only and warns users not to submit sensitive information. |
| Creator platform examples including Instagram, TikTok, YouTube, Facebook, Shopify, Etsy, Amazon, OnlyFans, Patreon, Substack, and affiliate income | Platform names are used descriptively; support with website archive and client-service scope review | Avoid implying endorsement, affiliation, or platform-specific expertise beyond understanding planning issues. Privacy language is framed around confidentiality and professionalism, not testimonials. |
| "Confidential, no cost, no obligation" first consultation | Firm policy and intake process | Do not use "high reward" or "no risk" because those can sound promissory. Keep the framing limited to consultation cost and obligation. |

## Copy Removed or Avoided

- Guarantees, guaranteed returns, risk-free wording, or certainty of outcome.
- Rankings, "best advisor" claims, awards, or third-party endorsements.
- Testimonials, client reviews, or implied client experiences.
- Claims of being conflict-free.
- Performance references, expected returns, or market-timing claims.
- Any reference to a disclosure document that is not applicable to this state-registered adviser context.

## V81 Interaction Review Notes

- The path-finder quiz does not collect or store answers locally beyond the browser session; it routes visitors to educational pages or the contact page.
- The quiz copy avoids "you should buy/sell/invest" language and uses "may," "starting point," and "educational" framing.
- Profile pages describe possible planning areas and use "help organize," "coordinate," and "review" language rather than promising tax savings, investment returns, or specific financial outcomes.
- Ask an Advisor fallback cards are topic prompts for the YouTube channel. Production integration should confirm that displayed video titles remain educational and do not create testimonials, endorsements, performance claims, or promissory language.
