const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");

if (toggle && nav) {
  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
  });

  nav.addEventListener("click", (event) => {
    if (event.target instanceof HTMLAnchorElement) {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    }
  });
}

const current = window.location.pathname.split("/").pop() || "index.html";
document.querySelectorAll(".main-nav a").forEach((link) => {
  const href = link.getAttribute("href") || "";
  if (href === current || (current === "" && href === "index.html")) {
    link.setAttribute("aria-current", "page");
  }
});

const contactForm = document.querySelector("[data-contact-form]");

if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(contactForm);
    const isSpanish = contactForm.dataset.formLang === "es";
    const subject = encodeURIComponent(isSpanish ? "Solicitud de consulta - Germana Capital" : "Consultation request - Germana Capital");
    const labels = isSpanish
      ? ["Nombre", "Email", "Teléfono", "Principalmente busco", "¿Qué motivó la conversación?"]
      : ["Name", "Email", "Phone", "Looking for", "What prompted the conversation?"];
    const body = encodeURIComponent(
      [
        `${labels[0]}: ${formData.get("name") || ""}`,
        `${labels[1]}: ${formData.get("email") || ""}`,
        `${labels[2]}: ${formData.get("phone") || ""}`,
        `${labels[3]}: ${formData.get("profile") || ""}`,
        "",
        labels[4],
        `${formData.get("message") || ""}`
      ].join("\n")
    );

    window.location.href = `mailto:contact@germanacapital.com?subject=${subject}&body=${body}`;
  });
}

const pathFinderData = {
  en: {
    quizzes: {
      general: {
        questions: [
          {
            label: "What sounds most like you right now?",
            options: [
              { text: "I have cash sitting around and I do not know what to do with it.", score: "cash" },
              { text: "I recently came into money due to an inheritance, settlement, lottery, or another one-time event, and I need a plan.", score: "sudden" },
              { text: "I make good money but still feel financially disorganized.", score: "planning" },
              { text: "I am a content creator and I have never thought about having a financial plan.", score: "creator" },
              { text: "I am a pro athlete and I do not know what I am going to do after I retire.", score: "athlete" },
              { text: "I am retired, but I feel like my investments are not working for me.", score: "retired" },
              { text: "I own U.S. assets or property as a non-U.S. person.", score: "international" },
              { text: "I am just curious whether I could be doing something different.", score: "curious" }
            ]
          }
        ],
        followUps: {
          cash: [
            { label: "What worries you most about the cash?", options: [{ text: "Leaving too much in the bank.", score: "cash" }, { text: "Investing it all at the wrong time.", score: "portfolio" }, { text: "Not knowing what taxes or big purchases are coming.", score: "tax" }, { text: "I just want someone to explain my options.", score: "curious" }] },
            { label: "What would make you feel more comfortable?", options: [{ text: "A bucket for emergency cash.", score: "cash" }, { text: "A plan for investing gradually.", score: "portfolio" }, { text: "A list of what to ask my CPA or attorney.", score: "tax" }, { text: "A no-cost first conversation.", score: "fit" }] }
          ],
          planning: [
            { label: "Where does the disorganization show up most?", options: [{ text: "Too many accounts and no dashboard.", score: "planning" }, { text: "Credit cards, spending, and savings are hard to track.", score: "cash" }, { text: "I do not know if retirement is on track.", score: "portfolio" }, { text: "Taxes surprise me.", score: "tax" }] },
            { label: "What would help first?", options: [{ text: "Organize the full picture.", score: "planning" }, { text: "Explain what each account is for.", score: "portfolio" }, { text: "Build rules for cash flow.", score: "cash" }, { text: "Talk through it privately.", score: "fit" }] }
          ],
          sudden: [
            { label: "What best describes the money event?", options: [{ text: "Inheritance or family transfer.", score: "sudden" }, { text: "Legal settlement or claim payment.", score: "tax" }, { text: "Lottery, gambling, or prize winnings.", score: "tax" }, { text: "Sale, bonus, or another one-time amount.", score: "sudden" }] },
            { label: "What feels most urgent right now?", options: [{ text: "Knowing where the money should sit while I decide.", score: "cash" }, { text: "Understanding possible tax questions.", score: "tax" }, { text: "Not making a rushed investment decision.", score: "portfolio" }, { text: "Handling family pressure or requests.", score: "planning" }] }
          ],
          creator: [
            { label: "Where does creator income feel messiest?", options: [{ text: "Instagram, TikTok, or YouTube money comes in unevenly.", score: "creator" }, { text: "Brand deals and affiliate income make taxes confusing.", score: "tax" }, { text: "Shopify, Etsy, or Amazon revenue mixes with expenses.", score: "business" }, { text: "I am nervous about being judged for how I earn.", score: "creator" }] },
            { label: "What would you want help organizing first?", options: [{ text: "Business versus personal money.", score: "creator" }, { text: "Tax reserves for 1099 or platform income.", score: "tax" }, { text: "What to invest and what to keep liquid.", score: "portfolio" }, { text: "A confidential first conversation.", score: "fit" }] }
          ],
          athlete: [
            { label: "What athlete money issue feels most real?", options: [{ text: "I do not know how long the income will last.", score: "athlete" }, { text: "Taxes across salary, bonuses, NIL, or endorsements are confusing.", score: "tax" }, { text: "Everyone has an opinion about what I should do with the money.", score: "planning" }, { text: "I need a plan for life after the sport.", score: "athlete" }] },
            { label: "What would help first?", options: [{ text: "Cash-flow rules while income is strong.", score: "cash" }, { text: "A career-transition plan.", score: "athlete" }, { text: "Investment structure that accounts for uncertainty.", score: "portfolio" }, { text: "A confidential conversation.", score: "fit" }] }
          ],
          retired: [
            { label: "What feels off about retirement right now?", options: [{ text: "My investments do not seem to support my spending.", score: "retired" }, { text: "I worry about taking too much out.", score: "cash" }, { text: "Taxes on withdrawals are confusing.", score: "tax" }, { text: "I want a second opinion on the portfolio.", score: "portfolio" }] },
            { label: "What would make retirement feel clearer?", options: [{ text: "A withdrawal plan.", score: "retired" }, { text: "A portfolio risk review.", score: "portfolio" }, { text: "A tax-aware distribution discussion.", score: "tax" }, { text: "A private first conversation.", score: "fit" }] }
          ],
          international: [
            { label: "Which U.S. issue applies most?", options: [{ text: "I want to invest in the U.S. but do not know how.", score: "international" }, { text: "I own South Florida property.", score: "international" }, { text: "I have U.S. accounts or U.S.-situated assets.", score: "international" }, { text: "My family and assets are spread across countries.", score: "planning" }] },
            { label: "What should the first conversation cover?", options: [{ text: "Investment structure.", score: "portfolio" }, { text: "Estate planning coordination for U.S. assets.", score: "international" }, { text: "Liquidity and currency needs.", score: "cash" }, { text: "Who else should be involved.", score: "tax" }] }
          ],
          curious: [
            { label: "What made you curious?", options: [{ text: "I feel like I should be doing something smarter.", score: "curious" }, { text: "I do not know whether my advisor is doing enough.", score: "fit" }, { text: "I saw cash or investments grow and want a plan.", score: "cash" }, { text: "A friend mentioned financial planning and I have never done it.", score: "planning" }] },
            { label: "What would make a first call worth it?", options: [{ text: "A plain-English diagnosis.", score: "curious" }, { text: "A list of what to organize first.", score: "planning" }, { text: "Understanding fees and conflicts.", score: "fit" }, { text: "No cost and no pressure.", score: "fit" }] }
          ],
          business: [
            { label: "Where does business money feel messy?", options: [{ text: "Business cash and personal cash mix together.", score: "business" }, { text: "Tax reserves are not consistent.", score: "tax" }, { text: "Most of my wealth is tied to the business.", score: "portfolio" }, { text: "I do not know what to move out of the business.", score: "cash" }] },
            { label: "What would help first?", options: [{ text: "Separating reserves and owner pay.", score: "business" }, { text: "Coordinating with my CPA.", score: "tax" }, { text: "Building personal wealth outside the business.", score: "portfolio" }, { text: "A confidential first conversation.", score: "fit" }] }
          ]
        }
      },
      creator: {
        questions: [
          { label: "Where does your creator money come from most often?", options: [{ text: "Instagram, TikTok, YouTube, Facebook, or Snapchat.", score: "creator" }, { text: "OnlyFans, Patreon, Substack, memberships, or subscriptions.", score: "creator" }, { text: "Shopify, Etsy, Amazon, merch, or digital products.", score: "business" }, { text: "Brand deals, affiliates, speaking, or several sources.", score: "tax" }] },
          { label: "What feels most uncomfortable right now?", options: [{ text: "Nobody withholds taxes and I do not know what to reserve.", score: "tax" }, { text: "Income spikes and drops with algorithms or campaigns.", score: "cash" }, { text: "I am not sure what money belongs to the business or to me.", score: "business" }, { text: "I worry an advisor will judge how I earn.", score: "creator" }] },
          { label: "What would be most useful first?", options: [{ text: "A tax-reserve and cash-flow system.", score: "tax" }, { text: "Rules for business cash, personal cash, and investing.", score: "business" }, { text: "A plan for what to keep liquid versus invest.", score: "portfolio" }, { text: "A confidential, no-cost conversation.", score: "fit" }] }
        ]
      },
      athlete: {
        questions: [
          { label: "What part of athlete money feels least clear?", options: [{ text: "What happens after I retire from the sport.", score: "athlete" }, { text: "Taxes on salary, NIL, bonuses, or endorsements.", score: "tax" }, { text: "How much I can spend versus save.", score: "cash" }, { text: "Who to trust around money decisions.", score: "fit" }] },
          { label: "What pressure do you feel most?", options: [{ text: "Family, friends, or lifestyle expectations.", score: "planning" }, { text: "Short career window.", score: "athlete" }, { text: "Uneven payments or contract timing.", score: "cash" }, { text: "Too many people pitching investments.", score: "fit" }] },
          { label: "What should be organized first?", options: [{ text: "Cash-flow rules and reserves.", score: "cash" }, { text: "Career transition planning.", score: "athlete" }, { text: "Investment policy.", score: "portfolio" }, { text: "A confidential, no-cost consultation.", score: "fit" }] }
        ]
      },
      business: {
        questions: [
          { label: "Where is the business-owner problem?", options: [{ text: "Business cash is high but I do not know what to move personally.", score: "cash" }, { text: "Taxes happen too late.", score: "tax" }, { text: "Most of my wealth is inside the company.", score: "portfolio" }, { text: "I need a plan before selling or expanding.", score: "business" }] },
          { label: "What gets ignored most often?", options: [{ text: "Personal investments.", score: "portfolio" }, { text: "Retirement planning.", score: "planning" }, { text: "Owner pay and reserves.", score: "business" }, { text: "Estate or succession coordination.", score: "tax" }] },
          { label: "What would help first?", options: [{ text: "Separate business and personal cash.", score: "business" }, { text: "Coordinate with my CPA.", score: "tax" }, { text: "Build wealth outside the business.", score: "portfolio" }, { text: "A confidential, no-cost consultation.", score: "fit" }] }
        ]
      },
      sudden: {
        questions: [
          { label: "What best describes the source of the money?", options: [{ text: "Inheritance or family transfer.", score: "sudden" }, { text: "Legal settlement or claim payment.", score: "tax" }, { text: "Lottery, gambling, or prize winnings.", score: "tax" }, { text: "Sale, bonus, or another large one-time amount.", score: "sudden" }] },
          { label: "Where is most of the money right now?", options: [{ text: "Checking or savings.", score: "cash" }, { text: "Temporary account or money market.", score: "cash" }, { text: "Already invested in a few places.", score: "portfolio" }, { text: "Split across accounts or I am not sure.", score: "planning" }] },
          { label: "What would help first?", options: [{ text: "A short-term holding plan before big decisions.", score: "cash" }, { text: "A list of tax and legal questions to coordinate.", score: "tax" }, { text: "A phased investment plan.", score: "portfolio" }, { text: "A confidential, no-cost consultation.", score: "fit" }] }
        ]
      },
      professional: {
        questions: [
          { label: "What is your biggest professional planning issue?", options: [{ text: "Salary, bonus, and equity feel disconnected.", score: "planning" }, { text: "RSUs, options, or employer stock create concentration.", score: "portfolio" }, { text: "Taxes are higher than expected.", score: "tax" }, { text: "I save, but I do not know if it is enough.", score: "retired" }] },
          { label: "Where do decisions usually get stuck?", options: [{ text: "What to do with cash.", score: "cash" }, { text: "When to sell or diversify equity.", score: "portfolio" }, { text: "Which benefits or retirement accounts to use.", score: "planning" }, { text: "Whether an advisor is worth it.", score: "fit" }] },
          { label: "What would help first?", options: [{ text: "A full financial map.", score: "planning" }, { text: "A portfolio and equity review.", score: "portfolio" }, { text: "A tax-aware savings structure.", score: "tax" }, { text: "A confidential, no-cost consultation.", score: "fit" }] }
        ]
      },
      international: {
        questions: [
          { label: "What U.S. planning question matters most?", options: [{ text: "How to invest in the U.S.", score: "international" }, { text: "South Florida property and estate tax exposure.", score: "international" }, { text: "U.S. brokerage or bank accounts.", score: "portfolio" }, { text: "Family and assets across countries.", score: "planning" }] },
          { label: "What is hardest to understand?", options: [{ text: "Who should hold what account.", score: "international" }, { text: "What money should stay liquid.", score: "cash" }, { text: "Which professionals need to coordinate.", score: "tax" }, { text: "Whether I can get advice as a non-U.S. client.", score: "fit" }] },
          { label: "What would help first?", options: [{ text: "A U.S. asset planning map.", score: "international" }, { text: "Investment policy.", score: "portfolio" }, { text: "Tax and estate coordination questions.", score: "tax" }, { text: "A confidential, no-cost consultation.", score: "fit" }] }
        ]
      }
    },
    results: {
      cash: { title: "Start with a cash plan, not an investment product.", body: "You may need to separate emergency money, taxes, short-term goals, and long-term capital before deciding what should be invested.", href: "insights.html#one-million", cta: "See the $1M+ guide" },
      planning: { title: "You probably need a financial system.", body: "The issue may not be income. It may be that your cash flow, accounts, taxes, savings, and goals are not working from the same plan.", href: "services.html", cta: "See planning services" },
      creator: { title: "Creator income deserves a real financial plan.", body: "Platform income, brand deals, subscriptions, affiliate revenue, merch, and online sales can create tax, cash-flow, privacy, and planning questions that deserve a system.", href: "creators.html", cta: "Open creator path" },
      athlete: { title: "Your earning window needs a plan for what comes next.", body: "Athlete income can be early, uneven, and time-limited. Planning can help organize cash flow, taxes, investing, and career transition questions.", href: "athletes.html", cta: "Open athlete path" },
      retired: { title: "Retirement income needs a different kind of review.", body: "If the portfolio does not feel like it is working for you, the issue may involve withdrawals, risk, taxes, liquidity, or expectations.", href: "portfolio-planning.html", cta: "Review the portfolio approach" },
      sudden: { title: "Sudden wealth needs a pause before a plan.", body: "A large one-time amount can create relief, pressure, tax questions, family requests, and investment decisions all at once. The starting point is often to protect flexibility while the facts are organized.", href: "sudden-wealth.html", cta: "Open sudden wealth path" },
      variable: { title: "Variable income needs rules before investments.", body: "Creators, athletes, entrepreneurs, and commission-based professionals often need tax reserves, spending rules, and liquidity before portfolio design.", href: "who-we-serve.html", cta: "Find your profile" },
      business: { title: "Business money and personal wealth need separate lanes.", body: "Owner pay, business reserves, personal liquidity, taxes, and investing usually need a structure that does not depend on whatever is left over.", href: "business-owners.html", cta: "Open business owner path" },
      international: { title: "U.S. assets can create U.S. planning questions.", body: "If you are not a U.S. person, U.S. bank accounts, investments, entities, and South Florida property may require extra planning coordination.", href: "international-clients.html", cta: "View international planning" },
      tax: { title: "Tax surprises are usually a planning problem.", body: "We do not replace your CPA, but we help coordinate cash flow, investments, and timing so tax questions are not handled at the last minute.", href: "services.html#coordination", cta: "See coordination areas" },
      portfolio: { title: "A portfolio without a plan can feel random.", body: "Investment decisions should connect to time horizon, liquidity, taxes, risk, and what the money is actually for.", href: "portfolio-planning.html", cta: "See portfolio planning" },
      fit: { title: "You may be looking for independent advice.", body: "Our fee-only model is designed to reduce product-compensation conflicts. The first call is confidential, no cost, and no obligation.", href: "how-we-work.html", cta: "See how we work" },
      curious: { title: "Curiosity is a valid reason to ask.", body: "You do not need a crisis to review whether your cash, taxes, investments, and accounts are organized the way they should be.", href: "contact.html?source=curious", cta: "Ask a no-cost question" }
    },
    restart: "Start over",
    consult: "Confidential no-cost consultation"
  },
  es: {
    quizzes: {
      general: {
        questions: [
          {
            label: "¿Qué se parece más a tu situación?",
            options: [
              { text: "Tengo efectivo acumulado y no sé qué hacer.", score: "cash" },
              { text: "Recibí una suma importante por herencia, acuerdo legal, lotería u otro evento único, y necesito un plan.", score: "sudden" },
              { text: "Gano bien, pero siento que todo está desordenado.", score: "planning" },
              { text: "Soy creador de contenido y nunca pensé en tener un plan financiero.", score: "creator" },
              { text: "Soy deportista profesional y no sé qué haré después del retiro.", score: "athlete" },
              { text: "Estoy retirado, pero siento que mis inversiones no trabajan para mí.", score: "retired" },
              { text: "Tengo activos o propiedad en EE. UU. siendo extranjero.", score: "international" },
              { text: "Tengo curiosidad por saber si podría estar haciendo algo diferente.", score: "curious" }
            ]
          }
        ],
        followUps: {
          creator: [
            { label: "¿Dónde se siente más desordenado el ingreso de creador?", options: [{ text: "Instagram, TikTok o YouTube pagan de forma variable.", score: "creator" }, { text: "Marcas y afiliados complican impuestos.", score: "tax" }, { text: "Shopify, Etsy o ventas online mezclan ingresos y gastos.", score: "business" }, { text: "Me preocupa sentirme juzgado por cómo gano dinero.", score: "creator" }] },
            { label: "¿Qué quisieras ordenar primero?", options: [{ text: "Dinero del negocio versus dinero personal.", score: "creator" }, { text: "Reservas fiscales.", score: "tax" }, { text: "Qué invertir y qué mantener líquido.", score: "portfolio" }, { text: "Una conversación confidencial.", score: "fit" }] }
          ],
          athlete: [
            { label: "¿Qué tema de deportista se siente más real?", options: [{ text: "No sé cuánto durará el ingreso.", score: "athlete" }, { text: "Impuestos de salario, bonos, NIL o patrocinios.", score: "tax" }, { text: "Demasiadas opiniones alrededor del dinero.", score: "planning" }, { text: "Necesito plan para después del deporte.", score: "athlete" }] },
            { label: "¿Qué ayudaría primero?", options: [{ text: "Reglas de flujo de caja.", score: "cash" }, { text: "Plan de transición.", score: "athlete" }, { text: "Estructura de inversión.", score: "portfolio" }, { text: "Consulta confidencial.", score: "fit" }] }
          ],
          retired: [
            { label: "¿Qué se siente mal en el retiro?", options: [{ text: "Mis inversiones no sostienen mi estilo de vida.", score: "retired" }, { text: "Me preocupa retirar demasiado.", score: "cash" }, { text: "Los impuestos de retiros me confunden.", score: "tax" }, { text: "Quiero segunda opinión del portafolio.", score: "portfolio" }] },
            { label: "¿Qué daría más claridad?", options: [{ text: "Plan de retiros.", score: "retired" }, { text: "Revisión de riesgo.", score: "portfolio" }, { text: "Distribución fiscalmente consciente.", score: "tax" }, { text: "Primera conversación privada.", score: "fit" }] }
          ],
          international: [
            { label: "¿Qué tema de EE. UU. aplica más?", options: [{ text: "Quiero invertir en EE. UU.", score: "international" }, { text: "Tengo propiedad en South Florida.", score: "international" }, { text: "Tengo cuentas o activos en EE. UU.", score: "international" }, { text: "Mi familia y activos están en varios países.", score: "planning" }] },
            { label: "¿Qué debería cubrir la primera conversación?", options: [{ text: "Estructura de inversión.", score: "portfolio" }, { text: "Planificación patrimonial para activos en EE. UU.", score: "international" }, { text: "Liquidez y moneda.", score: "cash" }, { text: "Qué profesionales deben coordinar.", score: "tax" }] }
          ],
          cash: [
            { label: "¿Qué te preocupa del efectivo?", options: [{ text: "Dejar demasiado en el banco.", score: "cash" }, { text: "Invertir todo en mal momento.", score: "portfolio" }, { text: "Impuestos o compras grandes.", score: "tax" }, { text: "Quiero entender mis opciones.", score: "curious" }] },
            { label: "¿Qué daría más comodidad?", options: [{ text: "Reserva de emergencia.", score: "cash" }, { text: "Invertir por etapas.", score: "portfolio" }, { text: "Preguntas para CPA o abogado.", score: "tax" }, { text: "Consulta sin costo.", score: "fit" }] }
          ],
          planning: [
            { label: "¿Dónde se nota más el desorden?", options: [{ text: "Muchas cuentas sin mapa.", score: "planning" }, { text: "Gasto, ahorro y tarjetas.", score: "cash" }, { text: "No sé si voy bien para retiro.", score: "portfolio" }, { text: "Impuestos me sorprenden.", score: "tax" }] },
            { label: "¿Qué ayudaría primero?", options: [{ text: "Ordenar el cuadro completo.", score: "planning" }, { text: "Saber para qué sirve cada cuenta.", score: "portfolio" }, { text: "Reglas de flujo de caja.", score: "cash" }, { text: "Hablar en privado.", score: "fit" }] }
          ],
          sudden: [
            { label: "¿Qué describe mejor el origen del dinero?", options: [{ text: "Herencia o transferencia familiar.", score: "sudden" }, { text: "Acuerdo legal, demanda o reclamo.", score: "tax" }, { text: "Lotería, premio o juegos de azar.", score: "tax" }, { text: "Venta, bono u otra suma única.", score: "sudden" }] },
            { label: "¿Qué se siente más urgente?", options: [{ text: "Saber dónde dejar el dinero mientras decido.", score: "cash" }, { text: "Entender posibles preguntas fiscales.", score: "tax" }, { text: "No invertir apresuradamente.", score: "portfolio" }, { text: "Manejar presión o pedidos familiares.", score: "planning" }] }
          ],
          curious: [
            { label: "¿Qué despertó la curiosidad?", options: [{ text: "Siento que debería hacer algo mejor.", score: "curious" }, { text: "No sé si mi asesor hace suficiente.", score: "fit" }, { text: "Creció mi efectivo o inversiones.", score: "cash" }, { text: "Nunca hice planificación financiera.", score: "planning" }] },
            { label: "¿Qué haría valiosa la primera llamada?", options: [{ text: "Diagnóstico en lenguaje claro.", score: "curious" }, { text: "Lista de qué organizar primero.", score: "planning" }, { text: "Entender honorarios y conflictos.", score: "fit" }, { text: "Sin costo y sin presión.", score: "fit" }] }
          ]
        }
      },
      creator: {
        questions: [
          { label: "¿De dónde viene la mayor parte de tu ingreso como creador?", options: [{ text: "Instagram, TikTok, YouTube, Facebook o Snapchat.", score: "creator" }, { text: "OnlyFans, Patreon, Substack, membresías o suscripciones.", score: "creator" }, { text: "Shopify, Etsy, Amazon, merch o productos digitales.", score: "business" }, { text: "Marcas, afiliados, cursos, lanzamientos o varias fuentes.", score: "tax" }] },
          { label: "¿Qué se siente más incómodo o desordenado?", options: [{ text: "Nadie retiene impuestos y no sé cuánto reservar.", score: "tax" }, { text: "El ingreso sube y baja por campañas o algoritmos.", score: "cash" }, { text: "No sé qué dinero es del negocio y qué dinero es mío.", score: "business" }, { text: "Me preocupa que un asesor juzgue cómo gano dinero.", score: "creator" }] },
          { label: "¿Qué te ayudaría primero?", options: [{ text: "Un sistema para reservas fiscales y meses lentos.", score: "tax" }, { text: "Separar dinero del negocio, personal e inversiones.", score: "business" }, { text: "Saber qué mantener líquido y qué invertir.", score: "portfolio" }, { text: "Una conversación confidencial sin costo.", score: "fit" }] }
        ]
      },
      athlete: {
        questions: [
          { label: "¿Qué parte del dinero como deportista te preocupa más?", options: [{ text: "No sé qué haré después del retiro deportivo.", score: "athlete" }, { text: "Impuestos de salario, NIL, bonos o patrocinios.", score: "tax" }, { text: "Cuánto puedo gastar sin poner en riesgo el futuro.", score: "cash" }, { text: "No sé en quién confiar para decisiones de dinero.", score: "fit" }] },
          { label: "¿Qué presión se siente más fuerte?", options: [{ text: "Familia, amigos o expectativas de estilo de vida.", score: "planning" }, { text: "Una carrera que puede durar menos de lo esperado.", score: "athlete" }, { text: "Pagos variables o contratos por etapas.", score: "cash" }, { text: "Demasiadas personas ofreciendo inversiones.", score: "fit" }] },
          { label: "¿Qué debería organizarse primero?", options: [{ text: "Reglas de flujo de caja y reservas.", score: "cash" }, { text: "Plan para la transición después del deporte.", score: "athlete" }, { text: "Estructura de inversión según la incertidumbre.", score: "portfolio" }, { text: "Consulta confidencial sin costo.", score: "fit" }] }
        ]
      },
      business: {
        questions: [
          { label: "¿Dónde aparece el problema como dueño de negocio?", options: [{ text: "El negocio tiene efectivo, pero no sé cuánto puedo mover.", score: "cash" }, { text: "Los impuestos se atienden demasiado tarde.", score: "tax" }, { text: "La mayor parte de mi patrimonio está dentro de la empresa.", score: "portfolio" }, { text: "Necesito ordenar antes de vender, crecer o asociarme.", score: "business" }] },
          { label: "¿Qué suele quedar para después?", options: [{ text: "Inversiones personales fuera del negocio.", score: "portfolio" }, { text: "Planificación de retiro.", score: "planning" }, { text: "Pago del dueño y reservas.", score: "business" }, { text: "Coordinación patrimonial o sucesoria.", score: "tax" }] },
          { label: "¿Qué te ayudaría primero?", options: [{ text: "Separar caja del negocio y caja personal.", score: "business" }, { text: "Coordinar preguntas con mi CPA.", score: "tax" }, { text: "Crear patrimonio fuera de la empresa.", score: "portfolio" }, { text: "Consulta confidencial sin costo.", score: "fit" }] }
        ]
      },
      sudden: {
        questions: [
          { label: "¿Qué describe mejor el origen del dinero?", options: [{ text: "Herencia o transferencia familiar.", score: "sudden" }, { text: "Acuerdo legal, demanda o reclamo.", score: "tax" }, { text: "Lotería, premio o juegos de azar.", score: "tax" }, { text: "Venta, bono u otra suma importante de una sola vez.", score: "sudden" }] },
          { label: "¿Dónde está la mayor parte del dinero hoy?", options: [{ text: "Cuenta corriente o ahorro.", score: "cash" }, { text: "Cuenta temporal o money market.", score: "cash" }, { text: "Ya invertido en algunos lugares.", score: "portfolio" }, { text: "En varios lugares o no estoy seguro.", score: "planning" }] },
          { label: "¿Qué te ayudaría primero?", options: [{ text: "Un plan temporal antes de tomar decisiones grandes.", score: "cash" }, { text: "Lista de preguntas fiscales y legales para coordinar.", score: "tax" }, { text: "Un plan de inversión por etapas.", score: "portfolio" }, { text: "Consulta confidencial sin costo.", score: "fit" }] }
        ]
      },
      professional: {
        questions: [
          { label: "¿Cuál es tu principal tema como profesional?", options: [{ text: "Sueldo, bono y acciones no están conectados en un plan.", score: "planning" }, { text: "RSUs, opciones o acciones de la empresa concentran riesgo.", score: "portfolio" }, { text: "Pago más impuestos de lo que esperaba.", score: "tax" }, { text: "Ahorro, pero no sé si voy bien para retiro.", score: "retired" }] },
          { label: "¿Dónde se trancan las decisiones?", options: [{ text: "Qué hacer con el efectivo.", score: "cash" }, { text: "Cuándo vender o diversificar acciones.", score: "portfolio" }, { text: "Qué beneficios o cuentas de retiro usar.", score: "planning" }, { text: "Si vale la pena contratar un asesor.", score: "fit" }] },
          { label: "¿Qué te ayudaría primero?", options: [{ text: "Un mapa financiero completo.", score: "planning" }, { text: "Revisión de portafolio y acciones de empresa.", score: "portfolio" }, { text: "Estructura de ahorro con conciencia fiscal.", score: "tax" }, { text: "Consulta confidencial sin costo.", score: "fit" }] }
        ]
      },
      international: {
        questions: [
          { label: "¿Qué pregunta sobre EE. UU. importa más?", options: [{ text: "Quiero invertir en EE. UU. y no sé cómo empezar.", score: "international" }, { text: "Tengo una propiedad en South Florida.", score: "international" }, { text: "Tengo cuentas bancarias o de inversión en EE. UU.", score: "portfolio" }, { text: "Mi familia y mis activos están en varios países.", score: "planning" }] },
          { label: "¿Qué es lo más difícil de entender?", options: [{ text: "A nombre de quién o de qué estructura deberían estar las cuentas.", score: "international" }, { text: "Cuánto dinero debería quedar líquido.", score: "cash" }, { text: "Qué profesionales deben coordinar entre países.", score: "tax" }, { text: "Si puedo recibir asesoría siendo cliente internacional.", score: "fit" }] },
          { label: "¿Qué te ayudaría primero?", options: [{ text: "Mapa de activos y preguntas de planificación en EE. UU.", score: "international" }, { text: "Política de inversión.", score: "portfolio" }, { text: "Preguntas para coordinar con abogados y contadores.", score: "tax" }, { text: "Consulta confidencial sin costo.", score: "fit" }] }
        ]
      }
    },
    results: {
      cash: { title: "Empieza con un plan para el efectivo.", body: "Antes de invertir, puede convenir separar emergencias, impuestos, metas cercanas y capital de largo plazo.", href: "contact.html?source=spanish-cash", cta: "Hablar sobre mi efectivo" },
      planning: { title: "Probablemente necesitas un sistema financiero.", body: "El problema no siempre es el ingreso. Muchas veces falta una estructura que conecte cuentas, impuestos, ahorro y metas.", href: "who-we-serve.html", cta: "Ver todos los perfiles" },
      creator: { title: "Tu ingreso de creador merece un sistema real.", body: "Plataformas, marcas, suscripciones, afiliados y ventas online pueden crear preguntas de impuestos, flujo de caja y privacidad.", href: "creators.html", cta: "Ver ruta de creadores" },
      athlete: { title: "Tu ventana de ingresos necesita plan para lo que viene.", body: "El ingreso deportivo puede ser temprano, variable y limitado. La planificación ayuda a ordenar liquidez, impuestos, inversión y transición.", href: "athletes.html", cta: "Ver ruta de deportistas" },
      retired: { title: "El retiro necesita una revisión distinta.", body: "Si el portafolio no parece trabajar para ti, puede haber temas de retiros, riesgo, impuestos o liquidez.", href: "contact.html?source=spanish-retirement", cta: "Hablar sobre mi retiro" },
      sudden: { title: "Una suma importante necesita pausa antes de plan.", body: "Un evento de liquidez puede traer alivio, presión, preguntas fiscales, pedidos familiares y decisiones de inversión al mismo tiempo. El punto de partida suele ser proteger flexibilidad mientras se ordenan los hechos.", href: "sudden-wealth.html", cta: "Ver ruta de patrimonio repentino" },
      variable: { title: "Los ingresos variables necesitan reglas.", body: "Creadores, deportistas, empresarios y profesionales con comisiones suelen necesitar reservas, liquidez y reglas antes de invertir.", href: "who-we-serve.html", cta: "Ver perfiles" },
      business: { title: "El dinero del negocio y el patrimonio personal necesitan carriles separados.", body: "Pago del dueño, reservas, liquidez personal, impuestos e inversiones necesitan estructura.", href: "business-owners.html", cta: "Ver ruta de empresarios" },
      international: { title: "Los activos en EE. UU. requieren más planificación.", body: "Cuentas, inversiones, entidades y propiedades en South Florida pueden generar preguntas de impuestos y patrimonio.", href: "international-clients.html", cta: "Ver ruta internacional" },
      tax: { title: "Las sorpresas fiscales suelen ser un problema de planificación.", body: "No reemplazamos a tu CPA, pero coordinamos flujo de caja, inversiones y tiempos para evitar improvisar.", href: "contact.html?source=spanish-tax", cta: "Hablar sobre impuestos" },
      portfolio: { title: "Un portafolio sin plan se siente aleatorio.", body: "Las inversiones deben conectarse con horizonte, liquidez, impuestos, riesgo y objetivos.", href: "portfolio-planning.html", cta: "Ver planificación de portafolio" },
      fit: { title: "Buscas asesoría independiente.", body: "El modelo de honorarios está diseñado para reducir conflictos por venta de productos. La primera llamada es confidencial, sin costo y sin obligación.", href: "contact.html?source=spanish-fit", cta: "Hablar con un asesor" },
      curious: { title: "La curiosidad es una buena razón para preguntar.", body: "No necesitas una crisis para revisar si efectivo, impuestos, inversiones y cuentas están bien organizados.", href: "contact.html?source=curious", cta: "Hacer una pregunta sin costo" }
    },
    restart: "Empezar de nuevo",
    consult: "Consulta confidencial sin costo"
  }
};

function initPathFinder(root) {
  const lang = root.dataset.lang === "es" ? "es" : "en";
  const data = pathFinderData[lang];
  const quizType = root.dataset.quizType || "general";
  const quiz = data.quizzes[quizType] || data.quizzes.general;
  const progress = root.querySelector("[data-quiz-progress]");
  const question = root.querySelector("[data-quiz-question]");
  const options = root.querySelector("[data-quiz-options]");
  const result = root.querySelector("[data-quiz-result]");
  const scores = {};
  let primary = null;
  let step = 0;

  function getQuestion() {
    if (step === 0) return quiz.questions[0];
    if (quiz.followUps && primary && quiz.followUps[primary]) {
      return quiz.followUps[primary][step - 1];
    }
    return quiz.questions[step];
  }

  function renderQuestion() {
    const item = getQuestion();
    if (!item || !progress || !question || !options || !result) return;
    const total = quiz.followUps ? 3 : quiz.questions.length;
    progress.textContent = `${step + 1}/${total}`;
    question.textContent = item.label;
    result.innerHTML = "";
    options.innerHTML = item.options.map((option) => `<button class="quiz-option" type="button" data-score="${option.score}">${option.text}</button>`).join("");
  }

  function topResult() {
    return Object.entries(scores).sort((a, b) => b[1] - a[1])[0]?.[0] || "planning";
  }

  function renderResult() {
    const key = topResult();
    const picked = data.results[key] || data.results.planning;
    if (!progress || !question || !options || !result) return;
    progress.textContent = lang === "es" ? "Tu punto de partida" : "Your starting point";
    question.textContent = "";
    options.innerHTML = "";
    result.innerHTML = `
      <div class="quiz-result">
        <h3>${picked.title}</h3>
        <p>${picked.body}</p>
        <div class="quiz-actions">
          <a class="btn btn-primary" href="${picked.href}">${picked.cta}</a>
          <a class="btn btn-secondary" href="contact.html?source=path-finder&result=${encodeURIComponent(key)}">${data.consult}</a>
          <button class="quiz-reset" type="button" data-quiz-reset>${data.restart}</button>
        </div>
      </div>`;
  }

  root.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const option = target.closest("[data-score]");
    if (option instanceof HTMLElement) {
      const score = option.dataset.score || "planning";
      if (step === 0) primary = score;
      scores[score] = (scores[score] || 0) + 1;
      step += 1;
      const total = quiz.followUps ? 3 : quiz.questions.length;
      if (step < total) renderQuestion();
      else renderResult();
    }
    if (target.closest("[data-quiz-reset]")) {
      Object.keys(scores).forEach((key) => delete scores[key]);
      primary = null;
      step = 0;
      renderQuestion();
    }
  });

  renderQuestion();
}

document.querySelectorAll("[data-path-finder]").forEach(initPathFinder);

const videoFallback = [
  { tag: "Start here", title: "How do I know if I actually need a financial advisor?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Cash", title: "I have money sitting in the bank. What should I do first?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Sudden wealth", title: "I inherited money or received a settlement. What should I think through first?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Fees", title: "Fee-only advisor, broker, bank advisor: what is the difference?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Taxes", title: "Why high income still feels messy after taxes", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Creators", title: "What creators and 1099 earners usually miss", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "International", title: "U.S. assets and property: what foreign clients should ask", url: "https://www.youtube.com/@AdvisorAnswers" }
];

const videoFallbackEs = [
  { tag: "Empieza aquí", title: "¿Cómo sé si realmente necesito un asesor financiero?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Efectivo", title: "Tengo dinero en el banco. ¿Qué debería revisar primero?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Patrimonio repentino", title: "Recibí una herencia o acuerdo legal. ¿Qué debería revisar primero?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Honorarios", title: "Asesor de honorarios, broker o banco: ¿cuál es la diferencia?", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Impuestos", title: "Por qué un buen ingreso puede sentirse desordenado después de impuestos", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Creadores", title: "Lo que creadores y trabajadores 1099 suelen pasar por alto", url: "https://www.youtube.com/@AdvisorAnswers" },
  { tag: "Internacional", title: "Activos y propiedades en EE. UU.: preguntas para clientes extranjeros", url: "https://www.youtube.com/@AdvisorAnswers" }
];

function renderVideos(videos) {
  document.querySelectorAll("[data-video-grid]").forEach((grid) => {
    const fallback = grid.dataset.lang === "es" ? videoFallbackEs : videoFallback;
    const items = videos.length ? videos : fallback;
    grid.innerHTML = items.slice(0, 6).map((video) => `
      <a class="video-card" href="${video.url}" target="_blank" rel="noopener">
        <div class="video-thumb"><strong>${video.title}</strong></div>
        <div class="video-body">
          <div class="video-tag">${video.tag || video.published || "Ask an Advisor"}</div>
          <div class="video-title">${video.title}</div>
        </div>
      </a>`).join("");
  });
}

async function loadVideos() {
  if (!document.querySelector("[data-video-grid]")) return;
  try {
    const isStaticPreview = ["localhost", "127.0.0.1", "::1"].includes(window.location.hostname) && window.location.port;
    if (isStaticPreview) {
      renderVideos([]);
      return;
    }
    const response = await fetch("/api/youtube-feed", { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error("feed");
    const data = await response.json();
    renderVideos(Array.isArray(data.videos) ? data.videos : []);
  } catch {
    renderVideos([]);
  }
}

loadVideos();

document.querySelectorAll("[data-topic-form]").forEach((form) => {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const isSpanish = form.dataset.formLang === "es";
    const subject = encodeURIComponent(isSpanish ? "Solicitud de tema para Ask an Advisor" : "Ask an Advisor topic request");
    const labels = isSpanish
      ? ["Nombre", "Email", "Categoría", "Pregunta o tema"]
      : ["Name", "Email", "Topic", "Question or topic"];
    const body = encodeURIComponent(
      [
        `${labels[0]}: ${formData.get("name") || ""}`,
        `${labels[1]}: ${formData.get("email") || ""}`,
        `${labels[2]}: ${formData.get("topic") || ""}`,
        "",
        `${labels[3]}:`,
        `${formData.get("question") || ""}`
      ].join("\n")
    );
    window.location.href = `mailto:contact@germanacapital.com?subject=${subject}&body=${body}`;
  });
});

const params = new URLSearchParams(window.location.search);
if (params.has("source") && contactForm) {
  const message = contactForm.querySelector("#message");
  const profile = contactForm.querySelector("#profile");
  if (message instanceof HTMLTextAreaElement && !message.value) {
    const source = params.get("source") || "website";
    const result = params.get("result") || "";
    message.value = contactForm.dataset.formLang === "es"
      ? `Usé la herramienta ${source}${result ? ` y el resultado fue ${result}` : ""}. Me gustaría entender qué debería ordenar primero.`
      : `I used the ${source} tool${result ? ` and the result was ${result}` : ""}. I would like to understand what I should organize first.`;
  }
  if (profile instanceof HTMLSelectElement) {
    profile.value = contactForm.dataset.formLang === "es" ? "No estoy seguro todavía" : "Not sure yet";
  }
}
